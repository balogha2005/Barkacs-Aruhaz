﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace quizGame
{
    public partial class Form1 : Form
    {

        // változok
        int correctAnswer;
        int questionNumber = 1;
        int score;
        int percentage;
        int totalQuestions;


        public Form1()
        {
            InitializeComponent();

            askQuestion(questionNumber);

            totalQuestions = 10;



        }

        private void ClickAnswerEvent(object sender, EventArgs e)
        {

            var senderObject = (Button)sender;

            int buttonTag = Convert.ToInt32(senderObject.Tag);




            if (buttonTag == correctAnswer)
            {
                score++;


            }

            if (questionNumber == totalQuestions)
            {
                // eredmenyszamitas
                percentage = (int)Math.Round((double)(100 * score) / totalQuestions);


                MessageBox.Show("A kvíz véget ért!" + Environment.NewLine +
                                "Összesen " + score + " kérdést válaszoltál meg jól" + Environment.NewLine +
                                "Átlagod " + percentage + " %"

                    );

                score = 0;
                questionNumber = 0;

                askQuestion(questionNumber);
            }

            questionNumber++;

            askQuestion(questionNumber);



        }

        private void askQuestion(int qnum)
        {

            

            switch(qnum)
            {

                case 1:

                    lblQuestion.Text = "Mi az az osztály az objektum orientált programozásban?";

                    button1.Text = "Az osztály egy sablon, amely alapján létrehozhatók objektumok.";
                    button2.Text = "Egy változó típusa";
                    button3.Text = "Egy metódus neve";
                    button4.Text = "Egy tömb típusa";

                    correctAnswer = 1;

                    break;
                case 2:
                    lblQuestion.Text = "Mit jelent az \"öröklődés\" fogalma az objektum orientált programozásban?";

                    button1.Text = "Az öröklődés azt jelenti, hogy egy osztály mindig csak egyetlen másik osztálytól örökölhet";
                    button2.Text = "Az öröklődés azt jelenti, hogy egy osztály megörökölheti egy másik osztály tulajdonságait és metódusait.";
                    button3.Text = "Az öröklődés csak az attribútumokra vonatkozik, nem pedig a metódusokra";
                    button4.Text = " Az öröklődés csak az absztrakt osztályokra alkalmazható";

                    correctAnswer = 2;

                    break;

                case 3:


                    lblQuestion.Text = "Mi a konstruktor szerepe az objektum orientált programozásban?";

                    button1.Text = "A  konstruktor csak statikus metódusokat hívhat meg";
                    button2.Text = "A konstruktor nem lehet paraméteres";
                    button3.Text = "A konstruktor csak akkor hívódik meg, ha az osztályban nincs destruktor";
                    button4.Text = "A konstruktor felelős az osztály példányosításakor végrehajtandó inicializációs feladatokért.";

                    correctAnswer = 4;

                    break;

                case 4:


                    lblQuestion.Text = "Mi a különbség az absztrakt osztály és az interfész között?";

                    button1.Text = "Az absztrakt osztályok csak egyféle öröklődést támogatnak";
                    button2.Text = "Az absztrakt osztály lehet tartalmaz implementált metódusokat, míg az interfész csak metódusoknak a fejlécét definiálja, implementáció nélkül.";
                    button3.Text = "Az interfészekben csak konstruktorok lehetnek";
                    button4.Text = "Az absztrakt osztályok nem örökölhetnek más osztályokból";

                    correctAnswer = 2;

                    break;

                case 5:


                    lblQuestion.Text = "Mi az a statikus metódus az objektum orientált programozásban?";

                    button1.Text = "A statikus metódusok az osztályhoz tartoznak, nem pedig egy példányhoz, és a `static` kulcsszóval vannak ellátva.";
                    button2.Text = "Statikus metódusok mindig csak privát attribútumokkal dolgozhatnak";
                    button3.Text = "Statikus metódusok nem hivatkozhatnak nem statikus metódusokra";
                    button4.Text = "Egy osztályban csak egyetlen statikus metódus lehet";

                    correctAnswer = 1;

                    break;

                case 6:


                    lblQuestion.Text = "Mi a polimorfizmus szerepe az objektum orientált programozásban?";

                    button1.Text = "A polimorfizmus csak az interfészekkel alkalmazható";
                    button2.Text = "A polimorfizmus csak a konstruktorokra vonatkozik";
                    button3.Text = "A polimorfizmus lehetővé teszi, hogy az azonos nevű metódusok különböző osztályokban másképp viselkedjenek.";
                    button4.Text = "A polimorfizmus növeli a kód újrafelhasználhatóságát";

                    correctAnswer = 3;

                    break;

                case 7:


                    lblQuestion.Text = "Mi a destruktor szerepe az objektum orientált programozásban?";

                    button1.Text = "A destruktor felelős az objektum által lefoglalt erőforrások felszabadításáért, amikor az objektum megszűnik létezni.";
                    button2.Text = "Destruktorokat csak abban az esetben kell definiálni, ha az osztály tartalmaz statikus metódusokat";
                    button3.Text = "Destruktorok csak paraméterek nélkül hozhatók létre";
                    button4.Text = "Destruktorok csak a virtuális osztályokban használhatók";

                    correctAnswer = 1;

                    break;

                case 8:


                    lblQuestion.Text = "Mit jelent a \"composition\" fogalma az objektum orientált programozásban?";

                    button1.Text = "A composition csak az öröklődési hierarchiában lévő osztályok között alkalmazható";
                    button2.Text = "A composition mindig szorosabb kapcsolatot jelent, mint az öröklődés";
                    button3.Text = "A composition azt jelenti, hogy egy osztály más osztályok példányait tartalmazza, így egy szorosabb kapcsolat jön létre a két osztály között.";
                    button4.Text = "A composition csak akkor használható, ha az osztályok egy az egyben megvalósítják az interfészt";

                    correctAnswer = 3;

                    break;



                case 9:


                    lblQuestion.Text = "Mi az a túlterhelés (overloading) az objektum orientált programozásban?";

                    button1.Text = "Túlterhelés csak az absztrakt osztályokban alkalmazható";
                    button2.Text = "Túlterhelés csak akkor használható, ha az osztály egyetlen metódust tartalmaz";
                    button3.Text = "Túlterhelés csak az öröklődési hierarchiában szereplő osztályok között érvényese";
                    button4.Text = "A túlterhelés azt jelenti, hogy egy azonos nevű metódust többször is definiálhatunk az osztályban, de különböző paraméterlistával.";

                    correctAnswer = 4;

                    break;


                case 10:


                    lblQuestion.Text = "Milyen szerepet tölt be az interfész az objektum orientált programozásban?";

                    button1.Text = "Az interfészek mindig tartalmaznak implementációt a metódusaikhoz.";
                    button2.Text = "Az interfész egy szerződést definiál, amelyet egy osztálynak be kell tartania. Az interfész csak metódusokat, de nem tartalmaz implementációt.";
                    button3.Text = "Az interfészek csak privát metódusokat tartalmazhatnak";
                    button4.Text = "Egy osztály több interfészt is implementálhat egyszerre";

                    correctAnswer = 2;

                    break;




            }




        }

    }
}
